<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Edit Car</h1>
    <form method="POST" action="<?php echo e(route('cars.update', $car->id)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-group">
            <label for="name">Name</label>
            <input type="text" class="form-control" id="name" name="name" value="<?php echo e($car->name); ?>" required>
        </div>
        <div class="form-group">
            <label for="registration_number">Registration Number</label>
            <input type="text" class="form-control" id="registration_number" name="registration_number" value="<?php echo e($car->registration_number); ?>">
        </div>
        <div class="form-group">
            <label for="is_registered">Is Registered</label>
            <input type="checkbox" id="is_registered" name="is_registered" <?php echo e($car->is_registered ? 'checked' : ''); ?>>
        </div>
        <button type="submit" class="btn btn-primary">Save</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/danc1/Desktop/Laravel_projekt/myproject/resources/views/cars/edit.blade.php ENDPATH**/ ?>