<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Parts</h1>
    <a href="<?php echo e(route('parts.create')); ?>" class="btn btn-primary">Add Part</a>
    <table class="table">
        <thead>
            <tr>
                <th>Name</th>
                <th>Serial Number</th>
                <th>Car</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $parts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $part): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($part->name); ?></td>
                    <td><?php echo e($part->serialnumber); ?></td>
                    <td><?php echo e($part->car->name); ?></td>
                    <td>
                        <a href="<?php echo e(route('parts.edit', $part->id)); ?>" class="btn btn-warning">Edit</a>
                        <form action="<?php echo e(route('parts.destroy', $part->id)); ?>" method="POST" style="display:inline-block;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/danc1/Desktop/Laravel_projekt/myproject/resources/views/parts/index.blade.php ENDPATH**/ ?>