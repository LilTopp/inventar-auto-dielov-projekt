<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Add Car</h1>
    <form method="POST" action="<?php echo e(route('cars.store')); ?>">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="name">Name</label>
            <input type="text" class="form-control" id="name" name="name" required>
        </div>
        <div class="form-group">
            <label for="registration_number">Registration Number</label>
            <input type="text" class="form-control" id="registration_number" name="registration_number">
        </div>
        <div class="form-group">
            <label for="is_registered">Is Registered</label>
            <input type="checkbox" id="is_registered" name="is_registered">
        </div>
        <button type="submit" class="btn btn-primary">Save</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/danc1/Desktop/Laravel_projekt/myproject/resources/views/cars/create.blade.php ENDPATH**/ ?>