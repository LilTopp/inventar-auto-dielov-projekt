<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Cars</h1>
    <a href="<?php echo e(route('cars.create')); ?>" class="btn btn-primary">Add Car</a>
    <table class="table">
        <thead>
            <tr>
                <th>Name</th>
                <th>Registration Number</th>
                <th>Is Registered</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($car->name); ?></td>
                    <td><?php echo e($car->registration_number); ?></td>
                    <td><?php echo e($car->is_registered ? 'Yes' : 'No'); ?></td>
                    <td>
                        <a href="<?php echo e(route('cars.edit', $car->id)); ?>" class="btn btn-warning">Edit</a>
                        <form action="<?php echo e(route('cars.destroy', $car->id)); ?>" method="POST" style="display:inline-block;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/danc1/Desktop/Laravel_projekt/myproject/resources/views/cars/index.blade.php ENDPATH**/ ?>